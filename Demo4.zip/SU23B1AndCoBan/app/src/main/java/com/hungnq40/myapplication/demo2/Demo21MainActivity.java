package com.hungnq40.myapplication.demo2;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import com.hungnq40.myapplication.R;
public class Demo21MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_demo21_main);
    }
}