package com.hungnq40.myapplication.demo1;

import androidx.appcompat.app.AppCompatActivity;

import android.annotation.SuppressLint;
import android.os.Bundle;
import android.widget.TextView;

import com.hungnq40.myapplication.R;
public class Demo13MainActivity extends AppCompatActivity {
    TextView tv1; //khai bao textview
    @SuppressLint("MissingInflatedId")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_demo13_main);
        tv1=findViewById(R.id.demo13Tv1);//anh xa doi tuong giao dien vao code java
        //dua noi dung vao thanh phan giao dien
        tv1.setText(R.string.content);
    }
}