package com.hungnq40.myapplication.demo2;

import androidx.appcompat.app.AppCompatActivity;

import android.annotation.SuppressLint;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.RadioButton;
import android.widget.TextView;

import com.hungnq40.myapplication.R;
public class Demo22MainActivity extends AppCompatActivity {
    EditText txt1,txt2,txt3;//khai bao cac EditText
    RadioButton rdoNam,rdoNu;//khai bao cac RadioButton
    CheckBox chkDabong,chkChoiGame;//khai bao cac checkbox
    Button btn1;//khai bao button
    TextView tvKQ;//khai bao textview
    @SuppressLint("MissingInflatedId")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_demo22_main);
        //anh xa widget tu XML vao Java
        txt1=findViewById(R.id.demo22Txt1);
        txt2=findViewById(R.id.demo22Txt2);
        txt3=findViewById(R.id.demo22Txt3);
        rdoNam=findViewById(R.id.demo22RdoNam);
        rdoNu=findViewById(R.id.demo22RdoNu);
        chkDabong=findViewById(R.id.demo22ChkDaBong);
        chkChoiGame=findViewById(R.id.demo22ChkChoiGame);
        btn1=findViewById(R.id.demo22Btn1);
        tvKQ=findViewById(R.id.demo22TvKQ1);
    }

    //ham xu ly khi click vao button
    public void TinhToan(View view) {
        //Lay ve thong tin nguoi dung nhap vao
        String ten=txt1.getText().toString();
        String masv=txt2.getText().toString();
        String tuoi=txt3.getText().toString();
        //lay thong tin ve gioi tinh
        String gioiTinh="";
        if(rdoNam.isChecked())
        {
            gioiTinh=rdoNam.getText().toString();
        }
        else if(rdoNu.isChecked())
        {
            gioiTinh=rdoNu.getText().toString();
        }
        else
        {
            gioiTinh="Chua chon gioi tinh";
        }
        //lay thong tin ve so thich
        String sothich="";
        if(chkDabong.isChecked()&&chkChoiGame.isChecked())
        {
            sothich="Da bong va choi game";
        }
        else if(chkDabong.isChecked())
        {
            sothich=chkDabong.getText().toString();
        }
        else if(chkChoiGame.isChecked())
        {
            sothich=chkChoiGame.getText().toString();
        }
        else
        {
            sothich="Chua chon so thic";
        }
        //Dua vao bien ket qua
        String kq="Ho ten: "+ten+"\n"+
                "Tuoi: "+tuoi+"\n"+
                "Gioi tinh: "+gioiTinh+"\n"+
                "So thich: "+sothich+"\n";
        //hien thi ket qua
        tvKQ.setText(kq);
    }
}