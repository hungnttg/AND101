package com.hungnq40.myapplication.demo5;

import android.app.Activity;
import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.Filter;
import android.widget.Filterable;
import android.widget.TextView;

import com.hungnq40.myapplication.R;

import java.util.ArrayList;

public class Demo52Adapter extends BaseAdapter
implements Filterable
{
    private Context context;
    private ArrayList<Demo52Student> list,listOld;
    //khoi tao
    public Demo52Adapter(Context context, ArrayList<Demo52Student> list) {
        this.context = context;
        this.listOld=list;
        this.list = list;
    }
    //lay ve tong so tem
    @Override
    public int getCount() {
        return list.size();
    }
    //lay ve du lieu cua 1 item
    @Override
    public Object getItem(int position) {
        return list.get(position);
    }
    //lay ve id cua 1 item
    @Override
    public long getItemId(int position) {
        return position;
    }
    //tao view
    @Override
    public View getView(int position, View convertView, ViewGroup parent) {
        //b1-Ve layout va anh xa layout
        LayoutInflater inflater=((Activity)context).getLayoutInflater();//sinh layout
        convertView=inflater.inflate(R.layout.demo52_item_view,null);//anh xa layout
        //b2- anh xa thanh phan cua layout
        TextView tvCoSo=convertView.findViewById(R.id.demo52_item_tvCoSo);
        TextView tvHoTen=convertView.findViewById(R.id.demo52_item_tvHoTen);
        TextView tvDiaChi=convertView.findViewById(R.id.demo52_item_tvDiaChi);
        //b3-gan du lieu cho item
        tvCoSo.setText(list.get(position).getCoso());
        tvHoTen.setText(list.get(position).getHoten());
        tvDiaChi.setText(list.get(position).getDiachi());
        return convertView;
    }


    @Override
    public Filter getFilter() {
        return new Filter() {
            //nhap chuoi tim kiem theo ten
            @Override
            protected FilterResults performFiltering(CharSequence constraint) {
                String s=constraint.toString();//chuoi tim kiem
                if(s.isEmpty())
                {
                    list=listOld;
                }
                else
                {
                    ArrayList<Demo52Student> listST=new ArrayList<>();
                    for(Demo52Student st: list)
                    {
                        //neu chua dieu kien tim kiem
                        if(st.getHoten().toLowerCase().contains(s.toLowerCase()))
                        {
                            listST.add(st);//them vao list moi
                        }
                    }
                    list=listST;//gan lai list
                }
                FilterResults filterResults= new FilterResults();//dt chua ket qua tim kiem
                filterResults.values=list;
                return filterResults;
            }
            //tra ve ket qua
            @Override
            protected void publishResults(CharSequence constraint, FilterResults results) {
                list=(ArrayList<Demo52Student>) results.values;
                notifyDataSetChanged();//cap nhat vao listview
            }
        };
    }
}
