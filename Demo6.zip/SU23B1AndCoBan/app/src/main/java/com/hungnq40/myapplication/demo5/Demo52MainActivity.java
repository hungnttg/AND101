package com.hungnq40.myapplication.demo5;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import androidx.appcompat.widget.SearchView;
import androidx.appcompat.widget.Toolbar;

import android.annotation.SuppressLint;
import android.content.Intent;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.widget.Button;
import android.widget.ListView;

import com.hungnq40.myapplication.R;
import com.hungnq40.myapplication.demo4.Demo431MainActivity;

import java.util.ArrayList;

public class Demo52MainActivity extends AppCompatActivity {
    Button btnAdd;
    ListView listView;
    Toolbar toolbar;
    Demo52Adapter adapter;
    SearchView searchView;
    @SuppressLint("MissingInflatedId")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_demo52_main);
        btnAdd=findViewById(R.id.demo52BtnAdd);
        listView=findViewById(R.id.demo52Listview);

        toolbar=findViewById(R.id.demo61Toolbar2);
        setSupportActionBar(toolbar);
        getSupportActionBar().setDisplayShowHomeEnabled(true);
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);

        //Tao arraylist
        ArrayList<Demo52Student> list=new ArrayList<>();
        list.add(new Demo52Student("Ha Noi","Nguyen Van A","Hai Phong"));
        list.add(new Demo52Student("HCM","Tran Van A","bac Lieu"));
        list.add(new Demo52Student("Can Tho","Vu Van C","Nghe An"));
        list.add(new Demo52Student("Ha Noi","Nguyen Thi D","Ha Tinh"));
        list.add(new Demo52Student("Ha Noi","Nguyen Van A","Hai Phong"));
        list.add(new Demo52Student("HCM","Tran Van A","bac Lieu"));
        list.add(new Demo52Student("Can Tho","Vu Van C","Nghe An"));
        list.add(new Demo52Student("Ha Noi","Nguyen Thi D","Ha Tinh"));
        //tao adapter
         adapter=new Demo52Adapter(this,list);
        listView.setAdapter(adapter);
    }
    //ham tao menu
    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        MenuInflater inflater=getMenuInflater();//sinh layout
        inflater.inflate(R.menu.demo61_menu,menu);//anh xa menu
        MenuItem myMenuItem=menu.findItem(R.id.action_search1);//anh xa item
        searchView=(SearchView)myMenuItem.getActionView();//cho phep xu ly su kien
        //su kien: lang nghe su thay doi khi go Text
        searchView.setOnQueryTextListener(new SearchView.OnQueryTextListener() {
            @Override
            public boolean onQueryTextSubmit(String query) {
                adapter.getFilter().filter(query);
                return false;
            }

            @Override
            public boolean onQueryTextChange(String newText) {
                adapter.getFilter().filter(newText);
                return false;
            }
        });

    return true;
    }
    //xu ly su kien voi item menu
    @Override
    public boolean onOptionsItemSelected(@NonNull MenuItem item) {
        if(item.getItemId()==R.id.demo61ItemDangXuat)
        {
            Intent intent=new Intent(this,
                    Demo431MainActivity.class);
            startActivity(intent);
            finish();
        }
        else  if(item.getItemId()==R.id.demo61IteDiemDanh)
        {

        }
        return super.onOptionsItemSelected(item);
    }
}