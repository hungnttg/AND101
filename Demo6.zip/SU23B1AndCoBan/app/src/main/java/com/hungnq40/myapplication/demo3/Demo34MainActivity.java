package com.hungnq40.myapplication.demo3;

import androidx.appcompat.app.AppCompatActivity;
import com.hungnq40.myapplication.R;

import android.annotation.SuppressLint;
import android.os.Bundle;
import android.widget.ArrayAdapter;
import android.widget.ListView;

import com.hungnq40.myapplication.R;
public class Demo34MainActivity extends AppCompatActivity {
    ListView listView;//khai bao listview
    @SuppressLint("MissingInflatedId")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_demo34_main);
        listView=findViewById(R.id.demo34LV);//anh xa
        String[] nguonDL=new String[]{
            "Lap trinh java1",
            "Lap trinh java 2",
            "Android co ban",
            "Android nang cao",
            "Thiet ke giao dien android",
            "Android networking",
        };
        ArrayAdapter<String> adapter=new ArrayAdapter<>(this,
                android.R.layout.simple_list_item_1,nguonDL);
        listView.setAdapter(adapter);

    }
}