package com.hungnq40.myapplication.demo5;

import android.app.Activity;
import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.ImageView;
import android.widget.TextView;

import com.hungnq40.myapplication.R;

import java.util.ArrayList;

public class Demo51Adapter extends BaseAdapter {
    private Context context;
    private ArrayList<Demo51School> list;

    public Demo51Adapter(Context context, ArrayList<Demo51School> list) {
        this.context = context;
        this.list = list;
    }

    //lay ve tong item
    @Override
    public int getCount() {
        return list.size();
    }
    //lay ve item
    @Override
    public Object getItem(int position) {
        return list.get(position);
    }
    //lay ve id cua item
    @Override
    public long getItemId(int position) {
        return position;
    }
    //tao view
    //B1-Tao layout
    //b2-Anh xa thanh phan trong layout
    //b3: gan du lieu cho layout
    @Override
    public View getView(int position, View convertView, ViewGroup parent) {
        //B1-Tao layout
        LayoutInflater inflater=((Activity)context).getLayoutInflater();//tao layout
       convertView=inflater.inflate(R.layout.demo51_item_view,null);//gan voi form co san
        //b2-Anh xa thanh phan trong layout
        ImageView imgLogo=convertView.findViewById(R.id.demo51_item_image);
        TextView txtName=convertView.findViewById(R.id.demo51_item_textview);
        //b3: gan du lieu cho layout
        imgLogo.setImageResource(list.get(position).getImage());
        txtName.setText(list.get(position).getName());
        return convertView;
    }
}
