package com.hungnq40.myapplication.demo4;

import androidx.activity.result.ActivityResult;
import androidx.activity.result.ActivityResultCallback;
import androidx.activity.result.ActivityResultLauncher;
import androidx.activity.result.contract.ActivityResultContracts;
import androidx.appcompat.app.AppCompatActivity;

import android.annotation.SuppressLint;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

import com.hungnq40.myapplication.R;
public class Demo421MainActivity extends AppCompatActivity {
    Button btn1;
    EditText txt1;
    TextView tv1;
    @SuppressLint("MissingInflatedId")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_demo421_main);
        btn1=findViewById(R.id.demo421Btn1);
        txt1=findViewById(R.id.demo421Txt1);
        tv1=findViewById(R.id.demo421Tv1);
        //----thiet ke co che callback (lang nghe)
        ActivityResultLauncher<Intent> getData=registerForActivityResult(
                new ActivityResultContracts.StartActivityForResult(),
                new ActivityResultCallback<ActivityResult>() {
                    @Override
                    public void onActivityResult(ActivityResult result) {
                        if(result.getResultCode()==2)//2: ma code
                        {
                            Intent intent=result.getData();//lay ve du lieu
                            Bundle bundle=intent.getExtras();//lay ve goi du lieu
                            String data=bundle.getString("fromAc2");//lay du lieu theo key
                            tv1.setText(data);//dien du lieu nhan duoc tu AC2

                        }
                    }
                }
        );
        //---xu ly su kien
        btn1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent=new Intent(Demo421MainActivity.this,
                        Demo422MainActivity.class);//tao o to gui du lieu
                intent.putExtra("key",txt1.getText().toString());//dua du lieu len o to
                getData.launch(intent);//khoi hanh o to
            }
        });


    }
}