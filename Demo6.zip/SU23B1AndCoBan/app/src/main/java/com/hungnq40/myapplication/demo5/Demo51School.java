package com.hungnq40.myapplication.demo5;

public class Demo51School {
    private int image;
    private String name;

    public Demo51School(int image, String name) {
        this.image = image;
        this.name = name;
    }

    public Demo51School() {
    }

    public int getImage() {
        return image;
    }

    public void setImage(int image) {
        this.image = image;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }
}
