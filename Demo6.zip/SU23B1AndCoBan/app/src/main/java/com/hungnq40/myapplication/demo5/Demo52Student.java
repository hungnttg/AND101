package com.hungnq40.myapplication.demo5;

public class Demo52Student {
    private String coso;
    private String hoten;
    private String diachi;

    public Demo52Student(String coso, String hoten, String diachi) {
        this.coso = coso;
        this.hoten = hoten;
        this.diachi = diachi;
    }

    public Demo52Student() {
    }

    public String getCoso() {
        return coso;
    }

    public void setCoso(String coso) {
        this.coso = coso;
    }

    public String getHoten() {
        return hoten;
    }

    public void setHoten(String hoten) {
        this.hoten = hoten;
    }

    public String getDiachi() {
        return diachi;
    }

    public void setDiachi(String diachi) {
        this.diachi = diachi;
    }
}
