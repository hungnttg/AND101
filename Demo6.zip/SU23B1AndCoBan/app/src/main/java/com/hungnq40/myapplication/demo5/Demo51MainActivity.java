package com.hungnq40.myapplication.demo5;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.widget.Spinner;

import com.hungnq40.myapplication.R;

import java.util.ArrayList;

public class Demo51MainActivity extends AppCompatActivity {
    Spinner spinner;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_demo51_main);
        spinner=findViewById(R.id.demo51Spinner);
        //Tao nguon du lieu
        ArrayList<Demo51School> list=new ArrayList<>();
        list.add(new Demo51School(R.drawable.apple,"FPoly Ha Noi"));
        list.add(new Demo51School(R.drawable.dell,"FPoly HCM"));
        list.add(new Demo51School(R.drawable.android,"FPoly Ha Nam"));
        list.add(new Demo51School(R.drawable.facebook,"FPoly Can Tho"));
        //Gan du lieu voi Adapter va Spinner
        Demo51Adapter adapter=new Demo51Adapter(this,list);
        spinner.setAdapter(adapter);
    }
}