package com.hungnq40.myapplication.demo3;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import com.hungnq40.myapplication.R;
public class Demo34MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_demo34_main);
    }
}