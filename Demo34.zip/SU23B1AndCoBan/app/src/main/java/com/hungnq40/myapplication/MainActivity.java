package com.hungnq40.myapplication;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.widget.TextView;

public class MainActivity extends AppCompatActivity {
    TextView tv1; //khai bao textview
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        tv1 = findViewById(R.id.lab11Tv1);//anh xa thanh phan giao dien vao code java
        //dua du lieu vao thanh phan giao dien
        tv1.setText("Du lieu vua dua vao");
    }
}