package com.hungnq40.myapplication.demo5;

import androidx.activity.result.ActivityResult;
import androidx.activity.result.ActivityResultCallback;
import androidx.activity.result.ActivityResultLauncher;
import androidx.activity.result.contract.ActivityResultContracts;
import androidx.appcompat.app.AppCompatActivity;

import android.annotation.SuppressLint;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.Button;
import android.widget.ListView;
import android.widget.Toast;

import com.hungnq40.myapplication.R;

import java.util.ArrayList;

public class Demo52MainActivity extends AppCompatActivity {
    ListView listView;
    Button btn;
    @SuppressLint("MissingInflatedId")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_demo52_main);
        listView=findViewById(R.id.demo52Listview);
        btn=findViewById(R.id.demo52Btn1);
        //tao du lieu
        ArrayList<Demo52Student> list=new ArrayList<>();
        list.add(new Demo52Student("CS Ha Noi","Nguyen Van A","Thanh Hoa"));
        list.add(new Demo52Student("CS HCM","Tran Van B","Nghe An"));
        list.add(new Demo52Student("CS Ha Nam","Vu Van C","Ha Tinh"));
        list.add(new Demo52Student("CS Tay Nguyen","Hoang Thi D","Quang Binh"));
        Demo52ListviewAdapter adapter=new Demo52ListviewAdapter(this,list);
        listView.setAdapter(adapter);
        //----cai dat Activity For Result
        ActivityResultLauncher<Intent> getData=registerForActivityResult(
                new ActivityResultContracts.StartActivityForResult(),
                new ActivityResultCallback<ActivityResult>() {
                    @Override
                    public void onActivityResult(ActivityResult result) {
                        if(result.getResultCode()==2)
                        {
                            Intent intent=result.getData();//lay ve du lieu
                            Bundle bundle=intent.getExtras();//lay ve goi
                            String name=bundle.getString("name");
                            String address=bundle.getString("address");
                            String branch=bundle.getString("branch");
                            list.add(new Demo52Student(branch,name,address));
                            adapter.notifyDataSetChanged();
                        }
                    }
                }
        );
        //----xu ly su kien
        btn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent=new Intent(Demo52MainActivity.this,
                        Demo51MainActivity.class);
                getData.launch(intent);
            }
        });
    }
}