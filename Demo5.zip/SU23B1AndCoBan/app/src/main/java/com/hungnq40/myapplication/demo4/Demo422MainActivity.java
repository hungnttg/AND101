package com.hungnq40.myapplication.demo4;

import androidx.appcompat.app.AppCompatActivity;

import android.annotation.SuppressLint;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

import com.hungnq40.myapplication.R;
public class Demo422MainActivity extends AppCompatActivity {
    Button btn1;
    EditText txt1;
    TextView tv1;
    @SuppressLint("MissingInflatedId")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_demo422_main);
        btn1=findViewById(R.id.demo422Btn2);
        txt1=findViewById(R.id.demo422Txt2);
        tv1=findViewById(R.id.demo422Tv1);
        //nhan du lieu
        Intent intent2=getIntent();//don o to chuyen den
        String dulieu=intent2.getStringExtra("key");//do hang
        tv1.setText(dulieu);//dua du lieu len text
        btn1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent=new Intent();// tao o to
                Bundle bundle=new Bundle();// tao goi du lieu
                bundle.putString("fromAc2",txt1.getText().toString());//dua du lieu vao goi
                intent.putExtras(bundle);//dua goi du lieu vao o to
                setResult(2,intent);//thiet lap ma code
                finish();//ket thuc activity
            }
        });
    }
}