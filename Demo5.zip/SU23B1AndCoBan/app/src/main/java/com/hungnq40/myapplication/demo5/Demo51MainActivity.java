package com.hungnq40.myapplication.demo5;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Spinner;

import com.hungnq40.myapplication.R;

import java.util.ArrayList;

public class Demo51MainActivity extends AppCompatActivity {
    Spinner spinner;
    EditText txtName,txtDiaChi;
    Button btn;
    String selectedItemSpinner="";
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_demo51_main);
        spinner=findViewById(R.id.demo51Spinner);
        txtName=findViewById(R.id.demo51Txt1);
        txtDiaChi=findViewById(R.id.demo51Txt2);
        btn=findViewById(R.id.demo51Btn1);
        ArrayList<Demo51School> list=new ArrayList<>();
        list.add(new Demo51School(R.drawable.apple,"Ha Noi"));
        list.add(new Demo51School(R.drawable.dell,"HCM"));
        list.add(new Demo51School(R.drawable.facebook,"Tay Nguyen"));
        list.add(new Demo51School(R.drawable.apple,"Can Tho"));
        Demo51SpinnerAdapter adapter=new Demo51SpinnerAdapter(this,list);
        spinner.setAdapter(adapter);
        //xu ly su kien khi nguoi dung chon spinner
        spinner.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
                selectedItemSpinner=((Demo51School)spinner.getItemAtPosition(position)).getName();
            }

            @Override
            public void onNothingSelected(AdapterView<?> parent) {

            }
        });
        //--xu ly su kien submit
        btn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent=new Intent();
                Bundle bundle=new Bundle();
                bundle.putString("name",txtName.getText().toString());
                bundle.putString("address",txtDiaChi.getText().toString());
                bundle.putString("branch",selectedItemSpinner);
                intent.putExtras(bundle);
                setResult(2,intent);
                finish();
            }
        });

    }
}