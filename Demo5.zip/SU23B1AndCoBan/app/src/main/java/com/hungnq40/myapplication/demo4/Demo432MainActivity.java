package com.hungnq40.myapplication.demo4;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import com.hungnq40.myapplication.R;
public class Demo432MainActivity extends AppCompatActivity {
    EditText txt1,txt2,txt3;
    Button btn1;
    Intent intent2;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_demo432_main);
        txt1=findViewById(R.id.demo432Txt1);
        txt2=findViewById(R.id.demo432Txt2);
        txt3=findViewById(R.id.demo432Txt3);
        btn1=findViewById(R.id.demo432Btn1);
        btn1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                intent2=new Intent(Demo432MainActivity.this,
                        Demo431MainActivity.class);
                Bundle bundle=new Bundle();//tao goi du lieu
                bundle.putString("u",txt1.getText().toString());//dua user vao
                if(txt2.getText().toString().equals(txt3.getText().toString()))
                {
                    bundle.putString("p",txt2.getText().toString());//dua pass vao
                }
                else
                {
                    //neu sai pass thi dua ra thong bao
                    Toast.makeText(getApplicationContext(),"Mat khau khong khop",
                            Toast.LENGTH_LONG).show();
                    return;
                }
                intent2.putExtras(bundle);//dua goi du lieu vao o to
                startActivity(intent2);//chay o to
            }
        });
    }
}