package com.hungnq40.myapplication.demo4;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;

import com.hungnq40.myapplication.R;
public class Demo412MainActivity extends AppCompatActivity {
    Button btn2;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_demo412_main2);
        Log.i("Trang Thai","onCreate 412");
        btn2=findViewById(R.id.demo412Btn2);
        btn2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent=new Intent(Demo412MainActivity.this,
                        Demo411MainActivity.class);
                startActivity(intent);
            }
        });
    }

    @Override
    protected void onStart() {
        super.onStart();
        Log.i("Trang Thai","onStart 412");
    }

    @Override
    protected void onStop() {
        super.onStop();
        Log.i("Trang Thai","onStop 412");
    }

    @Override
    protected void onPause() {
        super.onPause();
        Log.i("Trang Thai","onPause 412");
    }

    @Override
    protected void onResume() {
        super.onResume();
        Log.i("Trang Thai","onResume 412");
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        Log.i("Trang Thai","onDestroy 412");
    }
}