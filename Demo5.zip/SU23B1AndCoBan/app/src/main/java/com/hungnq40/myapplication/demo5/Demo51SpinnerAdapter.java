package com.hungnq40.myapplication.demo5;

import android.app.Activity;
import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.ImageView;
import android.widget.TextView;

import com.hungnq40.myapplication.R;

import java.util.ArrayList;

public class Demo51SpinnerAdapter extends BaseAdapter {
    private Context context;
    private ArrayList<Demo51School> list;

    public Demo51SpinnerAdapter(Context context, ArrayList<Demo51School> list) {
        this.context = context;
        this.list = list;
    }

    @Override
    public int getCount() {
        return list.size();
    }

    @Override
    public Object getItem(int position) {
        return list.get(position);
    }

    @Override
    public long getItemId(int position) {
        return position;
    }
    //1.khoi tao va lien ket layout
    //2.Anh xa tung thanh phan tren layout
    //3. Dien du lieu
    @Override
    public View getView(int position, View convertView, ViewGroup parent) {
        //1.khoi tao va lien ket layout
        LayoutInflater inflater=((Activity)context).getLayoutInflater();//sinh layout
        convertView=inflater.inflate(R.layout.spinner_item_lab51,parent,false);//lien ket
        //2.Anh xa tung thanh phan tren layout
        ImageView imgLogo=convertView.findViewById(R.id.demo51_Item_image);
        TextView txtName=convertView.findViewById(R.id.demo51_Item_name);
        //3. Dien du lieu
        imgLogo.setImageResource(list.get(position).getImage());
        txtName.setText("Fpoly "+list.get(position).getName());
        return convertView;
    }
}
