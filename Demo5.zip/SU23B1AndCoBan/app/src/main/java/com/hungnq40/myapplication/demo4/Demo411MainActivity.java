package com.hungnq40.myapplication.demo4;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;

import com.hungnq40.myapplication.R;
public class Demo411MainActivity extends AppCompatActivity {
    Button btn1;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_demo411_main2);
        Log.i("Trang Thai","onCreate 411");
        btn1=findViewById(R.id.demo411Btn2);
        //xu ly su kien
        btn1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent=new Intent(Demo411MainActivity.this,
                        Demo412MainActivity.class);
                startActivity(intent);
            }
        });
    }

    @Override
    protected void onStart() {
        super.onStart();
        Log.i("Trang Thai","onStart 411");
    }

    @Override
    protected void onResume() {
        super.onResume();
        Log.i("Trang Thai","onResume 411");
    }

    @Override
    protected void onPause() {
        super.onPause();
        Log.i("Trang Thai","onPause 411");
    }

    @Override
    protected void onStop() {
        super.onStop();
        Log.i("Trang Thai","onStop 411");
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        Log.i("Trang Thai","onDestroy 411");
    }
}