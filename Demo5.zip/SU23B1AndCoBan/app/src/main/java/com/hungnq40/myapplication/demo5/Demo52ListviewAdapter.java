package com.hungnq40.myapplication.demo5;

import static com.hungnq40.myapplication.R.*;

import android.annotation.SuppressLint;
import android.app.Activity;
import android.app.AlertDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import androidx.activity.result.ActivityResultLauncher;

import com.hungnq40.myapplication.R;

import java.util.ArrayList;

public class Demo52ListviewAdapter extends BaseAdapter {
    private Context context;
    private ArrayList<Demo52Student> list;

    public Demo52ListviewAdapter(Context context, ArrayList<Demo52Student> list) {
        this.context = context;
        this.list = list;
    }

    @Override
    public int getCount() {
        return list.size();
    }

    @Override
    public Object getItem(int position) {
        return list.get(position);
    }

    @Override
    public long getItemId(int position) {
        return position;
    }

    @Override
    public View getView(int position, View convertView, ViewGroup parent) {
        //1. Tao layout va lien ket layout
        LayoutInflater inflater=((Activity)context).getLayoutInflater();
        convertView=inflater.inflate(layout.listview_item_demo52,parent,false);
        //2. Anh xa tung thanh phan cua layout
        TextView tvCoSo=convertView.findViewById(id.demo52_item_TvCoSo);
        TextView tvHoTen=convertView.findViewById(id.demo52_item_TvHoTen);
        TextView tvDiaChi=convertView.findViewById(id.demo52_item_TvDiaChi);
        Button btnDelete=convertView.findViewById(id.demo52BtnDelete);
        Button btnUpdate=convertView.findViewById(id.demo52BtnUpdate);
        //3. Dien du lieu
        tvCoSo.setText(list.get(position).getBranch());
        tvHoTen.setText(list.get(position).getName());
        tvDiaChi.setText(list.get(position).getAddress());
        btnDelete.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                list.remove(position);
                notifyDataSetChanged();
            }
        });
        btnUpdate.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                //tao 1 layout hien thi
                //tao dialog de gan voi layout
                AlertDialog.Builder builder=new AlertDialog.Builder(context);
                //--thanh lap dialog
                //b1-Tao layout
                LayoutInflater inflater1=((Activity) context).getLayoutInflater();
                View view1=inflater1.inflate(layout.dialog_bai54,null);
                builder.setView(view1);
                //b2-anh xa
                 final EditText txtCoSo=view1.findViewById(R.id.demo55Txt1);
                 final EditText txtTen=view1.findViewById(R.id.demo55Txt2);
                 final EditText txtDiaChi=view1.findViewById(R.id.demo55Txt3);
                 //b3-set tieu de
                builder.setTitle("update form");
                //b4. xu ly button cap nhat
                builder.setPositiveButton("Cap nhat", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                        //lay ve du lieu nhap vao dialog
                        String coso=txtCoSo.getText().toString();
                        String ten=txtTen.getText().toString();
                        String diachi=txtDiaChi.getText().toString();
                        //cap nhat vao list
                        list.get(position).setAddress(diachi);
                        list.get(position).setName(ten);
                        list.get(position).setBranch(coso);
                    }
                });
                //--
                AlertDialog alertDialog=builder.create();
                alertDialog.show();
            }
        });
        return convertView;
    }
}
