package com.hungnq40.myapplication.demo4;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import com.hungnq40.myapplication.R;
import com.hungnq40.myapplication.demo5.Demo52MainActivity;

public class Demo431MainActivity extends AppCompatActivity {
    EditText txtU,txtP;
    Button btnLogin,btnRegister;
    Intent intent;
    String u="",p="";
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_demo431_main);
        btnLogin=findViewById(R.id.demo431BtnLogin);
        btnRegister=findViewById(R.id.demo431BtnRegister);
        txtU=findViewById(R.id.demo431TxtU);
        txtP=findViewById(R.id.demo431TxtP);
        intent=getIntent();//lay ve intent gui den tu AC2
        if(intent!=null)
        {
            Bundle bundle=intent.getExtras();//lay ve goi du lieu
            if(bundle!=null)
            {
                //boc tach goi du lieu
                u=bundle.getString("u");
                p=bundle.getString("p");
            }
        }
        //xu ly su kien
        btnRegister.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                //goi den AC2
                Intent intent1=new Intent(Demo431MainActivity.this,
                        Demo432MainActivity.class);
                startActivity(intent1);
            }
        });
        btnLogin.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                boolean isU=u.equals(txtU.getText().toString());
                boolean isP=p.equals(txtP.getText().toString());
                if(isU&&isP&&u!=""&&p!="")
                {
                    Toast.makeText(getApplicationContext(),
                            "Dang nhap thanh cong",Toast.LENGTH_LONG).show();
                    Intent intent=new Intent(Demo431MainActivity.this,
                            Demo52MainActivity.class);
                    startActivity(intent);
                }
                else
                {
                    Toast.makeText(getApplicationContext(),
                            "Dang nhap khong thanh cong",Toast.LENGTH_LONG).show();
                }
            }
        });
    }
}